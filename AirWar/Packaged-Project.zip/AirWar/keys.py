def key_down(e):
    if e.type == 768 and e.key == 1073741905:
        return True
    return False
def key_down_up(e):
    if e.type == 769 and e.key == 1073741905:
        return True
    return False
def key_right(e):
    if e.type == 768 and e.key == 1073741903:
        return True
    return False
def key_up(e):
    if e.type == 768 and e.key == 1073741906:
        return True
    return False
def key_up_up(e):
    if e.type == 769 and e.key == 1073741906:
        return True
    return False
def key_left(e):
    if e.type == 768 and e.key == 1073741904:
        return True
    return False
def key_5(e):
    if e.type == 768 and e.key == 1073741917:
        return True
    return False
def key_9(e):
    if e.type == 768 and e.key == 1073741921:
        return True
    return False
def key_q(e):
    if e.type == 768 and e.key == 113:
        return True
    return False
def key_d(e):
    if e.type == 768 and e.key == 100:
        return True
    return False
def key_z(e):
    if e.type == 768 and e.key == 122:
        return True
    return False
def key_z_up(e):
    if e.type == 769 and e.key == 122:
        return True
    return False
def key_s(e):
    if e.type == 768 and e.key == 115:
        return True
    return False
def key_s_up(e):
    if e.type == 769 and e.key == 115:
        return True
    return False
def key_g(e):
    if e.type == 768 and e.key == 103:
        return True
    return False
def key_h(e):
    if e.type == 768 and e.key == 104:
        return True
    return False
def key_space(e):
    if e.type == 768 and e.key == 32:
        return True
    return False
def key_entrer(e):
    if e.type == 768 and e.key == 13:
        return True
    return False
def key_echap(e):
    if e.type == 768 and e.key == 27:
        return True
    return False  ##  ##5555555555555555